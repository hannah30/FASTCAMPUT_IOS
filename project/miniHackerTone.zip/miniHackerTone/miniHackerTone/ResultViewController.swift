

import UIKit

class ResultViewController: UIViewController {
  

  @IBOutlet weak var resultText: UILabel!
  @IBOutlet weak var resultTextField: UITextView!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    

  }
  
  override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
  }
  
  
  
}

