//
//  Result.swift
//  miniHackerTone
//
//  Created by okkoung on 2017. 11. 2..
//  Copyright © 2017년 okkoung. All rights reserved.
//

import Foundation

struct Result {
  
}
